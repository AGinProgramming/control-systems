clear
 
 [t,Y] = ode45(@Triangle_flocking_double_displacement,[0:0.01:40],[1 2 3 -1 -2 -3 4 4 0.2 0.2 0.2 0.2 0.2 0.2]);

% [t,Y] = ode45(@Triangle_flocking_double_displacement,[0:0.01:40],10*rand(14,1));


plot(Y(:,1),Y(:,2),'-.r',Y(:,3),Y(:,4),'--g',Y(:,5),Y(:,6),'b:',Y(:,7),Y(:,8),'k:','LineWidth',2.5)
legend('Agent 1','Agent 2','Agent 3','Leader agent')

% Xpoint_1000 = [Y(1000,1),Y(1000,3),Y(1000,5),Y(1000,7),Y(1000,1),Y(1000,5)];
% Ypoint_1000 = [Y(1000,2),Y(1000,4),Y(1000,6),Y(1000,8),Y(1000,2),Y(1000,6)];
hold on
plot([Y(1000,1),Y(1000,3),Y(1000,5),Y(1000,1)],[Y(1000,2),Y(1000,4),Y(1000,6),Y(1000,2)],'r:','LineWidth',2);
hold on
plot([Y(1000,1),Y(1000,7)],[Y(1000,2),Y(1000,8)],'b:','LineWidth',2);

plot([Y(3000,1),Y(3000,3),Y(3000,5),Y(3000,1)],[Y(3000,2),Y(3000,4),Y(3000,6),Y(3000,2)],'r:','LineWidth',2);
hold on
plot([Y(3000,1),Y(3000,7)],[Y(3000,2),Y(3000,8)],'b:','LineWidth',2);

plot([Y(4000,1),Y(4000,3),Y(4000,5),Y(4000,1)],[Y(4000,2),Y(4000,4),Y(4000,6),Y(4000,2)],'r:','LineWidth',2);
hold on
plot([Y(4000,1),Y(4000,7)],[Y(4000,2),Y(4000,8)],'b:','LineWidth',2);